
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/email-detect.mts
import { resolveMx, resolveSrv, resolve4 } from "node:dns/promises";
var config = {
  path: "/api/email-detect"
};
var ssl = (imapHost, smtpHost) => ({
  imapHost,
  imapPort: 993,
  imapSecurity: "SSL/TLS",
  smtpHost,
  smtpPort: 465,
  smtpSecurity: "SSL/TLS"
});
var PROVIDERS = [
  {
    key: "google",
    name: "Google Workspace",
    method: "oauth",
    mxMatches: ["aspmx.l.google.com", "googlemail.com", "google.com", "psmtp.com"],
    note: "Sign in with Google \u2014 no password is stored."
  },
  {
    key: "microsoft",
    name: "Microsoft 365",
    method: "oauth",
    mxMatches: ["mail.protection.outlook.com", "protection.outlook.com", "outlook.com", "office365.com"],
    note: "Sign in with Microsoft \u2014 no password is stored."
  },
  {
    key: "hostinger",
    name: "Hostinger Email",
    method: "credentials",
    mxMatches: ["hostinger", "titan.email"],
    settings: () => ssl("imap.titan.email", "smtp.titan.email"),
    note: "Hostinger mailboxes run on Titan. Use your mailbox password or an app password."
  },
  {
    key: "zoho",
    name: "Zoho Mail",
    method: "credentials",
    mxMatches: ["zoho.com", "zoho.eu", "zohomail"],
    settings: (domain) => domain.endsWith(".eu") ? ssl("imap.zoho.eu", "smtp.zoho.eu") : ssl("imap.zoho.com", "smtp.zoho.com"),
    note: "Zoho requires an application-specific password when two-factor is on."
  },
  {
    key: "fastmail",
    name: "Fastmail",
    method: "credentials",
    mxMatches: ["messagingengine.com", "fastmail"],
    settings: () => ssl("imap.fastmail.com", "smtp.fastmail.com"),
    note: "Fastmail requires an app password for IMAP and SMTP."
  },
  {
    key: "proton",
    name: "Proton Mail",
    method: "credentials",
    mxMatches: ["protonmail.ch", "proton.me", "protonmail.com"],
    settings: () => ({
      imapHost: "127.0.0.1",
      imapPort: 1143,
      imapSecurity: "STARTTLS (Proton Bridge)",
      smtpHost: "127.0.0.1",
      smtpPort: 1025,
      smtpSecurity: "STARTTLS (Proton Bridge)"
    }),
    note: "Proton needs Proton Bridge for IMAP access."
  },
  {
    key: "ionos",
    name: "IONOS",
    method: "credentials",
    mxMatches: ["ionos", "1and1", "kundenserver", "perfora"],
    settings: () => ssl("imap.ionos.com", "smtp.ionos.com")
  },
  {
    key: "ovh",
    name: "OVH",
    method: "credentials",
    mxMatches: ["ovh.net", "ovh.com"],
    settings: () => ssl("ssl0.ovh.net", "ssl0.ovh.net")
  },
  {
    key: "godaddy",
    name: "GoDaddy / Secureserver",
    method: "credentials",
    mxMatches: ["secureserver.net", "godaddy"],
    settings: () => ssl("imap.secureserver.net", "smtpout.secureserver.net")
  }
];
var TIMEOUT_MS = 2500;
async function withTimeout(work, fallback) {
  let timer;
  const timeout = new Promise((resolve) => {
    timer = setTimeout(() => resolve(fallback), TIMEOUT_MS);
  });
  try {
    return await Promise.race([work.catch(() => fallback), timeout]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}
function normaliseDomain(input) {
  const raw = input.trim().toLowerCase();
  const domain = raw.includes("@") ? raw.slice(raw.lastIndexOf("@") + 1) : raw;
  const cleaned = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "").replace(/\.$/, "");
  if (!/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/.test(cleaned)) return null;
  return cleaned;
}
function matchProvider(mx, domain) {
  const haystack = mx.join(" ");
  for (const provider of PROVIDERS) {
    if (provider.mxMatches.some((m) => haystack.includes(m))) {
      return {
        key: provider.key,
        name: provider.name,
        method: provider.method,
        settings: provider.settings ? provider.settings(domain) : null,
        note: provider.note ?? null
      };
    }
  }
  return null;
}
async function autodiscover(domain) {
  const srvAutodiscover = await withTimeout(resolveSrv(`_autodiscover._tcp.${domain}`), []);
  const srvImap = await withTimeout(resolveSrv(`_imaps._tcp.${domain}`), []);
  const srvSubmission = await withTimeout(
    resolveSrv(`_submission._tcp.${domain}`).catch(() => resolveSrv(`_submissions._tcp.${domain}`)),
    []
  );
  let https = false;
  try {
    const controller = new AbortController();
    const abort = setTimeout(() => controller.abort(), TIMEOUT_MS);
    const response = await fetch(`https://autodiscover.${domain}/autodiscover/autodiscover.xml`, {
      method: "GET",
      redirect: "follow",
      signal: controller.signal
    });
    clearTimeout(abort);
    https = response.status !== 404;
  } catch {
    https = false;
  }
  const guesses = await Promise.all(
    ["imap", "mail", "smtp"].map(async (prefix) => {
      const host = `${prefix}.${domain}`;
      const addresses = await withTimeout(resolve4(host), []);
      return addresses.length ? host : null;
    })
  );
  const imapHost = srvImap[0]?.name ?? guesses[0] ?? guesses[1];
  const smtpHost = srvSubmission[0]?.name ?? guesses[2] ?? guesses[1];
  const found = Boolean(srvAutodiscover.length || https || imapHost || smtpHost);
  return {
    tried: true,
    srv: srvAutodiscover.length > 0,
    https,
    found,
    microsoftLikely: srvAutodiscover.some((r) => r.name.toLowerCase().includes("outlook.com")) || srvAutodiscover.length > 0,
    settings: imapHost && smtpHost ? {
      imapHost,
      imapPort: srvImap[0]?.port ?? 993,
      imapSecurity: "SSL/TLS",
      smtpHost,
      smtpPort: srvSubmission[0]?.port ?? 587,
      smtpSecurity: srvSubmission[0]?.port === 465 ? "SSL/TLS" : "STARTTLS"
    } : null
  };
}
var email_detect_default = async (request) => {
  const url = new URL(request.url);
  const input = url.searchParams.get("email") ?? url.searchParams.get("domain") ?? "";
  const domain = normaliseDomain(input);
  const headers = { "content-type": "application/json", "cache-control": "no-store" };
  if (!domain) {
    return new Response(JSON.stringify({ error: "Provide ?email= or ?domain=" }), { status: 400, headers });
  }
  const records = await withTimeout(resolveMx(domain), []);
  const mx = records.sort((a, b) => a.priority - b.priority).map((r) => r.exchange.toLowerCase().replace(/\.$/, ""));
  const known = matchProvider(mx, domain);
  if (known) {
    return new Response(
      JSON.stringify({
        domain,
        provider: known.key,
        providerName: known.name,
        method: known.method,
        mx,
        checks: { incoming: true, outgoing: true, security: true },
        settings: known.settings,
        autodiscover: null,
        note: known.note,
        source: "mx"
      }),
      { headers }
    );
  }
  const discovery = await autodiscover(domain);
  if (discovery.found && discovery.microsoftLikely && !mx.length) {
    return new Response(
      JSON.stringify({
        domain,
        provider: "microsoft",
        providerName: "Microsoft 365",
        method: "oauth",
        mx,
        checks: { incoming: true, outgoing: true, security: true },
        settings: null,
        autodiscover: { srv: discovery.srv, https: discovery.https },
        note: "Found through Autodiscover rather than MX.",
        source: "autodiscover"
      }),
      { headers }
    );
  }
  if (discovery.settings) {
    return new Response(
      JSON.stringify({
        domain,
        provider: "autodiscovered",
        providerName: mx.length ? `Mail host at ${mx[0]}` : `Mail host for ${domain}`,
        method: "credentials",
        mx,
        checks: {
          incoming: Boolean(discovery.settings.imapHost),
          outgoing: Boolean(discovery.settings.smtpHost),
          security: true
        },
        settings: discovery.settings,
        autodiscover: { srv: discovery.srv, https: discovery.https },
        note: "Settings found by autodiscovery. Confirm them before connecting.",
        source: "autodiscover"
      }),
      { headers }
    );
  }
  return new Response(
    JSON.stringify({
      domain,
      provider: "unknown",
      providerName: "Unknown provider",
      method: "manual",
      mx,
      checks: { incoming: false, outgoing: false, security: false },
      settings: null,
      autodiscover: { srv: discovery.srv, https: discovery.https },
      note: mx.length ? `Your domain receives mail at ${mx[0]}, but we do not recognise it.` : "No mail servers found for this domain.",
      source: "none"
    }),
    { headers }
  );
};
export {
  config,
  email_detect_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibmV0bGlmeS9mdW5jdGlvbnMvZW1haWwtZGV0ZWN0Lm10cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyoqXG4gKiBFbWFpbCBwcm92aWRlciBkZXRlY3Rpb24uXG4gKlxuICogVGhlIG1hbmFnZXIgdHlwZXMgdGhlIG1haWxib3ggdGhleSB3YW50IGd1ZXN0IGVtYWlsIHRvIGFycml2ZSBpbjsgdGhpcyBydW5zIHRoZVxuICogbG9va3VwIGNoYWluIHRoZSBvbmJvYXJkaW5nIHdpemFyZCBkZXNjcmliZXM6XG4gKlxuICogICBleHRyYWN0IGRvbWFpbiAtPiBETlMgTVggbG9va3VwIC0+IHJlY29nbmlzZSBwcm92aWRlclxuICogICAgIGtub3duIHByb3ZpZGVyICAtPiByZXR1cm4gdGhlIHJpZ2h0IGNvbm5lY3Rpb24gbWV0aG9kIChPQXV0aCBvciBjcmVkZW50aWFscylcbiAqICAgICB1bmtub3duICAgICAgICAgLT4gYXV0b2Rpc2NvdmVyeSAoQXV0b2Rpc2NvdmVyIFNSViArIEhUVFBTLCBSRkMgNjE4NiBTUlYsIGhvc3QgZ3Vlc3NlcylcbiAqICAgICBzdGlsbCB1bmtub3duICAgLT4gdGVsbCB0aGUgY2xpZW50IHRvIHNob3cgbWFudWFsIElNQVAvU01UUCBzZXR0aW5nc1xuICpcbiAqIE5vdGhpbmcgaGVyZSBpcyBzdG9yZWQgYW5kIG5vIGNyZWRlbnRpYWwgaXMgZXZlciBhY2NlcHRlZCBieSB0aGlzIGVuZHBvaW50IC0tXG4gKiBpdCBvbmx5IGFuc3dlcnMgXCJob3cgc2hvdWxkIHRoaXMgbWFpbGJveCBiZSBjb25uZWN0ZWQ/XCIuXG4gKi9cblxuaW1wb3J0IHsgcmVzb2x2ZU14LCByZXNvbHZlU3J2LCByZXNvbHZlNCB9IGZyb20gXCJub2RlOmRucy9wcm9taXNlc1wiO1xuXG5leHBvcnQgY29uc3QgY29uZmlnID0ge1xuICBwYXRoOiBcIi9hcGkvZW1haWwtZGV0ZWN0XCIsXG59O1xuXG50eXBlIE1ldGhvZCA9IFwib2F1dGhcIiB8IFwiY3JlZGVudGlhbHNcIiB8IFwibWFudWFsXCI7XG5cbnR5cGUgU2VydmVyU2V0dGluZ3MgPSB7XG4gIGltYXBIb3N0OiBzdHJpbmc7XG4gIGltYXBQb3J0OiBudW1iZXI7XG4gIGltYXBTZWN1cml0eTogc3RyaW5nO1xuICBzbXRwSG9zdDogc3RyaW5nO1xuICBzbXRwUG9ydDogbnVtYmVyO1xuICBzbXRwU2VjdXJpdHk6IHN0cmluZztcbn07XG5cbnR5cGUgUHJvdmlkZXIgPSB7XG4gIGtleTogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIG1ldGhvZDogTWV0aG9kO1xuICAvKiogc3Vic3RyaW5ncyBtYXRjaGVkIGFnYWluc3QgdGhlIGRvbWFpbidzIE1YIGhvc3RuYW1lcywgbG93ZXJjYXNlZCAqL1xuICBteE1hdGNoZXM6IHN0cmluZ1tdO1xuICBzZXR0aW5ncz86IChkb21haW46IHN0cmluZykgPT4gU2VydmVyU2V0dGluZ3M7XG4gIG5vdGU/OiBzdHJpbmc7XG59O1xuXG5jb25zdCBzc2wgPSAoaW1hcEhvc3Q6IHN0cmluZywgc210cEhvc3Q6IHN0cmluZyk6IFNlcnZlclNldHRpbmdzID0+ICh7XG4gIGltYXBIb3N0LFxuICBpbWFwUG9ydDogOTkzLFxuICBpbWFwU2VjdXJpdHk6IFwiU1NML1RMU1wiLFxuICBzbXRwSG9zdCxcbiAgc210cFBvcnQ6IDQ2NSxcbiAgc210cFNlY3VyaXR5OiBcIlNTTC9UTFNcIixcbn0pO1xuXG5jb25zdCBQUk9WSURFUlM6IFByb3ZpZGVyW10gPSBbXG4gIHtcbiAgICBrZXk6IFwiZ29vZ2xlXCIsXG4gICAgbmFtZTogXCJHb29nbGUgV29ya3NwYWNlXCIsXG4gICAgbWV0aG9kOiBcIm9hdXRoXCIsXG4gICAgbXhNYXRjaGVzOiBbXCJhc3BteC5sLmdvb2dsZS5jb21cIiwgXCJnb29nbGVtYWlsLmNvbVwiLCBcImdvb2dsZS5jb21cIiwgXCJwc210cC5jb21cIl0sXG4gICAgbm90ZTogXCJTaWduIGluIHdpdGggR29vZ2xlIFx1MjAxNCBubyBwYXNzd29yZCBpcyBzdG9yZWQuXCIsXG4gIH0sXG4gIHtcbiAgICBrZXk6IFwibWljcm9zb2Z0XCIsXG4gICAgbmFtZTogXCJNaWNyb3NvZnQgMzY1XCIsXG4gICAgbWV0aG9kOiBcIm9hdXRoXCIsXG4gICAgbXhNYXRjaGVzOiBbXCJtYWlsLnByb3RlY3Rpb24ub3V0bG9vay5jb21cIiwgXCJwcm90ZWN0aW9uLm91dGxvb2suY29tXCIsIFwib3V0bG9vay5jb21cIiwgXCJvZmZpY2UzNjUuY29tXCJdLFxuICAgIG5vdGU6IFwiU2lnbiBpbiB3aXRoIE1pY3Jvc29mdCBcdTIwMTQgbm8gcGFzc3dvcmQgaXMgc3RvcmVkLlwiLFxuICB9LFxuICB7XG4gICAga2V5OiBcImhvc3RpbmdlclwiLFxuICAgIG5hbWU6IFwiSG9zdGluZ2VyIEVtYWlsXCIsXG4gICAgbWV0aG9kOiBcImNyZWRlbnRpYWxzXCIsXG4gICAgbXhNYXRjaGVzOiBbXCJob3N0aW5nZXJcIiwgXCJ0aXRhbi5lbWFpbFwiXSxcbiAgICBzZXR0aW5nczogKCkgPT4gc3NsKFwiaW1hcC50aXRhbi5lbWFpbFwiLCBcInNtdHAudGl0YW4uZW1haWxcIiksXG4gICAgbm90ZTogXCJIb3N0aW5nZXIgbWFpbGJveGVzIHJ1biBvbiBUaXRhbi4gVXNlIHlvdXIgbWFpbGJveCBwYXNzd29yZCBvciBhbiBhcHAgcGFzc3dvcmQuXCIsXG4gIH0sXG4gIHtcbiAgICBrZXk6IFwiem9ob1wiLFxuICAgIG5hbWU6IFwiWm9obyBNYWlsXCIsXG4gICAgbWV0aG9kOiBcImNyZWRlbnRpYWxzXCIsXG4gICAgbXhNYXRjaGVzOiBbXCJ6b2hvLmNvbVwiLCBcInpvaG8uZXVcIiwgXCJ6b2hvbWFpbFwiXSxcbiAgICBzZXR0aW5nczogKGRvbWFpbikgPT4gKGRvbWFpbi5lbmRzV2l0aChcIi5ldVwiKSA/IHNzbChcImltYXAuem9oby5ldVwiLCBcInNtdHAuem9oby5ldVwiKSA6IHNzbChcImltYXAuem9oby5jb21cIiwgXCJzbXRwLnpvaG8uY29tXCIpKSxcbiAgICBub3RlOiBcIlpvaG8gcmVxdWlyZXMgYW4gYXBwbGljYXRpb24tc3BlY2lmaWMgcGFzc3dvcmQgd2hlbiB0d28tZmFjdG9yIGlzIG9uLlwiLFxuICB9LFxuICB7XG4gICAga2V5OiBcImZhc3RtYWlsXCIsXG4gICAgbmFtZTogXCJGYXN0bWFpbFwiLFxuICAgIG1ldGhvZDogXCJjcmVkZW50aWFsc1wiLFxuICAgIG14TWF0Y2hlczogW1wibWVzc2FnaW5nZW5naW5lLmNvbVwiLCBcImZhc3RtYWlsXCJdLFxuICAgIHNldHRpbmdzOiAoKSA9PiBzc2woXCJpbWFwLmZhc3RtYWlsLmNvbVwiLCBcInNtdHAuZmFzdG1haWwuY29tXCIpLFxuICAgIG5vdGU6IFwiRmFzdG1haWwgcmVxdWlyZXMgYW4gYXBwIHBhc3N3b3JkIGZvciBJTUFQIGFuZCBTTVRQLlwiLFxuICB9LFxuICB7XG4gICAga2V5OiBcInByb3RvblwiLFxuICAgIG5hbWU6IFwiUHJvdG9uIE1haWxcIixcbiAgICBtZXRob2Q6IFwiY3JlZGVudGlhbHNcIixcbiAgICBteE1hdGNoZXM6IFtcInByb3Rvbm1haWwuY2hcIiwgXCJwcm90b24ubWVcIiwgXCJwcm90b25tYWlsLmNvbVwiXSxcbiAgICBzZXR0aW5nczogKCkgPT4gKHtcbiAgICAgIGltYXBIb3N0OiBcIjEyNy4wLjAuMVwiLFxuICAgICAgaW1hcFBvcnQ6IDExNDMsXG4gICAgICBpbWFwU2VjdXJpdHk6IFwiU1RBUlRUTFMgKFByb3RvbiBCcmlkZ2UpXCIsXG4gICAgICBzbXRwSG9zdDogXCIxMjcuMC4wLjFcIixcbiAgICAgIHNtdHBQb3J0OiAxMDI1LFxuICAgICAgc210cFNlY3VyaXR5OiBcIlNUQVJUVExTIChQcm90b24gQnJpZGdlKVwiLFxuICAgIH0pLFxuICAgIG5vdGU6IFwiUHJvdG9uIG5lZWRzIFByb3RvbiBCcmlkZ2UgZm9yIElNQVAgYWNjZXNzLlwiLFxuICB9LFxuICB7XG4gICAga2V5OiBcImlvbm9zXCIsXG4gICAgbmFtZTogXCJJT05PU1wiLFxuICAgIG1ldGhvZDogXCJjcmVkZW50aWFsc1wiLFxuICAgIG14TWF0Y2hlczogW1wiaW9ub3NcIiwgXCIxYW5kMVwiLCBcImt1bmRlbnNlcnZlclwiLCBcInBlcmZvcmFcIl0sXG4gICAgc2V0dGluZ3M6ICgpID0+IHNzbChcImltYXAuaW9ub3MuY29tXCIsIFwic210cC5pb25vcy5jb21cIiksXG4gIH0sXG4gIHtcbiAgICBrZXk6IFwib3ZoXCIsXG4gICAgbmFtZTogXCJPVkhcIixcbiAgICBtZXRob2Q6IFwiY3JlZGVudGlhbHNcIixcbiAgICBteE1hdGNoZXM6IFtcIm92aC5uZXRcIiwgXCJvdmguY29tXCJdLFxuICAgIHNldHRpbmdzOiAoKSA9PiBzc2woXCJzc2wwLm92aC5uZXRcIiwgXCJzc2wwLm92aC5uZXRcIiksXG4gIH0sXG4gIHtcbiAgICBrZXk6IFwiZ29kYWRkeVwiLFxuICAgIG5hbWU6IFwiR29EYWRkeSAvIFNlY3VyZXNlcnZlclwiLFxuICAgIG1ldGhvZDogXCJjcmVkZW50aWFsc1wiLFxuICAgIG14TWF0Y2hlczogW1wic2VjdXJlc2VydmVyLm5ldFwiLCBcImdvZGFkZHlcIl0sXG4gICAgc2V0dGluZ3M6ICgpID0+IHNzbChcImltYXAuc2VjdXJlc2VydmVyLm5ldFwiLCBcInNtdHBvdXQuc2VjdXJlc2VydmVyLm5ldFwiKSxcbiAgfSxcbl07XG5cbmNvbnN0IFRJTUVPVVRfTVMgPSAyNTAwO1xuXG5hc3luYyBmdW5jdGlvbiB3aXRoVGltZW91dDxUPih3b3JrOiBQcm9taXNlPFQ+LCBmYWxsYmFjazogVCk6IFByb21pc2U8VD4ge1xuICBsZXQgdGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgdW5kZWZpbmVkO1xuICBjb25zdCB0aW1lb3V0ID0gbmV3IFByb21pc2U8VD4oKHJlc29sdmUpID0+IHtcbiAgICB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gcmVzb2x2ZShmYWxsYmFjayksIFRJTUVPVVRfTVMpO1xuICB9KTtcbiAgdHJ5IHtcbiAgICByZXR1cm4gYXdhaXQgUHJvbWlzZS5yYWNlKFt3b3JrLmNhdGNoKCgpID0+IGZhbGxiYWNrKSwgdGltZW91dF0pO1xuICB9IGZpbmFsbHkge1xuICAgIGlmICh0aW1lcikgY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBub3JtYWxpc2VEb21haW4oaW5wdXQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCByYXcgPSBpbnB1dC50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgY29uc3QgZG9tYWluID0gcmF3LmluY2x1ZGVzKFwiQFwiKSA/IHJhdy5zbGljZShyYXcubGFzdEluZGV4T2YoXCJAXCIpICsgMSkgOiByYXc7XG4gIGNvbnN0IGNsZWFuZWQgPSBkb21haW4ucmVwbGFjZSgvXmh0dHBzPzpcXC9cXC8vLCBcIlwiKS5yZXBsYWNlKC9cXC8uKiQvLCBcIlwiKS5yZXBsYWNlKC9cXC4kLywgXCJcIik7XG4gIGlmICghL15bYS16MC05XShbYS16MC05LV0qW2EtejAtOV0pPyhcXC5bYS16MC05XShbYS16MC05LV0qW2EtejAtOV0pPykrJC8udGVzdChjbGVhbmVkKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiBjbGVhbmVkO1xufVxuXG5mdW5jdGlvbiBtYXRjaFByb3ZpZGVyKG14OiBzdHJpbmdbXSwgZG9tYWluOiBzdHJpbmcpIHtcbiAgY29uc3QgaGF5c3RhY2sgPSBteC5qb2luKFwiIFwiKTtcbiAgZm9yIChjb25zdCBwcm92aWRlciBvZiBQUk9WSURFUlMpIHtcbiAgICBpZiAocHJvdmlkZXIubXhNYXRjaGVzLnNvbWUoKG0pID0+IGhheXN0YWNrLmluY2x1ZGVzKG0pKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAga2V5OiBwcm92aWRlci5rZXksXG4gICAgICAgIG5hbWU6IHByb3ZpZGVyLm5hbWUsXG4gICAgICAgIG1ldGhvZDogcHJvdmlkZXIubWV0aG9kLFxuICAgICAgICBzZXR0aW5nczogcHJvdmlkZXIuc2V0dGluZ3MgPyBwcm92aWRlci5zZXR0aW5ncyhkb21haW4pIDogbnVsbCxcbiAgICAgICAgbm90ZTogcHJvdmlkZXIubm90ZSA/PyBudWxsLFxuICAgICAgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKlxuICogTWljcm9zb2Z0IGRvY3VtZW50cyB0aGF0IGEgY2xpZW50IGNhbiBkZXJpdmUgQXV0b2Rpc2NvdmVyIGVuZHBvaW50cyBmcm9tIHRoZSBtYWlsXG4gKiBkb21haW4sIGFuZCBmYWxsIGJhY2sgdG8gYSBETlMgU1JWIHJlY29yZC4gV2UgdHJ5IGJvdGgsIHBsdXMgdGhlIFJGQyA2MTg2IHNlcnZpY2VcbiAqIHJlY29yZHMgYW5kIHRoZSBjb252ZW50aW9uYWwgaG9zdCBuYW1lcywgYmVmb3JlIGdpdmluZyB1cCBhbmQgYXNraW5nIGZvciBtYW51YWwgc2V0dXAuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGF1dG9kaXNjb3Zlcihkb21haW46IHN0cmluZykge1xuICBjb25zdCBzcnZBdXRvZGlzY292ZXIgPSBhd2FpdCB3aXRoVGltZW91dChyZXNvbHZlU3J2KGBfYXV0b2Rpc2NvdmVyLl90Y3AuJHtkb21haW59YCksIFtdKTtcbiAgY29uc3Qgc3J2SW1hcCA9IGF3YWl0IHdpdGhUaW1lb3V0KHJlc29sdmVTcnYoYF9pbWFwcy5fdGNwLiR7ZG9tYWlufWApLCBbXSk7XG4gIGNvbnN0IHNydlN1Ym1pc3Npb24gPSBhd2FpdCB3aXRoVGltZW91dChcbiAgICByZXNvbHZlU3J2KGBfc3VibWlzc2lvbi5fdGNwLiR7ZG9tYWlufWApLmNhdGNoKCgpID0+IHJlc29sdmVTcnYoYF9zdWJtaXNzaW9ucy5fdGNwLiR7ZG9tYWlufWApKSxcbiAgICBbXSxcbiAgKTtcblxuICBsZXQgaHR0cHMgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGNvbnN0IGFib3J0ID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIFRJTUVPVVRfTVMpO1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYGh0dHBzOi8vYXV0b2Rpc2NvdmVyLiR7ZG9tYWlufS9hdXRvZGlzY292ZXIvYXV0b2Rpc2NvdmVyLnhtbGAsIHtcbiAgICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICAgIHJlZGlyZWN0OiBcImZvbGxvd1wiLFxuICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICB9KTtcbiAgICBjbGVhclRpbWVvdXQoYWJvcnQpO1xuICAgIC8vIEF1dG9kaXNjb3ZlciBhbnN3ZXJzIFBPU1RzOyBhIDQwMS80MDUvMjAwIGFsbCBwcm92ZSB0aGUgZW5kcG9pbnQgZXhpc3RzLlxuICAgIGh0dHBzID0gcmVzcG9uc2Uuc3RhdHVzICE9PSA0MDQ7XG4gIH0gY2F0Y2gge1xuICAgIGh0dHBzID0gZmFsc2U7XG4gIH1cblxuICBjb25zdCBndWVzc2VzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgW1wiaW1hcFwiLCBcIm1haWxcIiwgXCJzbXRwXCJdLm1hcChhc3luYyAocHJlZml4KSA9PiB7XG4gICAgICBjb25zdCBob3N0ID0gYCR7cHJlZml4fS4ke2RvbWFpbn1gO1xuICAgICAgY29uc3QgYWRkcmVzc2VzID0gYXdhaXQgd2l0aFRpbWVvdXQocmVzb2x2ZTQoaG9zdCksIFtdKTtcbiAgICAgIHJldHVybiBhZGRyZXNzZXMubGVuZ3RoID8gaG9zdCA6IG51bGw7XG4gICAgfSksXG4gICk7XG5cbiAgY29uc3QgaW1hcEhvc3QgPSBzcnZJbWFwWzBdPy5uYW1lID8/IGd1ZXNzZXNbMF0gPz8gZ3Vlc3Nlc1sxXTtcbiAgY29uc3Qgc210cEhvc3QgPSBzcnZTdWJtaXNzaW9uWzBdPy5uYW1lID8/IGd1ZXNzZXNbMl0gPz8gZ3Vlc3Nlc1sxXTtcblxuICBjb25zdCBmb3VuZCA9IEJvb2xlYW4oc3J2QXV0b2Rpc2NvdmVyLmxlbmd0aCB8fCBodHRwcyB8fCBpbWFwSG9zdCB8fCBzbXRwSG9zdCk7XG5cbiAgcmV0dXJuIHtcbiAgICB0cmllZDogdHJ1ZSxcbiAgICBzcnY6IHNydkF1dG9kaXNjb3Zlci5sZW5ndGggPiAwLFxuICAgIGh0dHBzLFxuICAgIGZvdW5kLFxuICAgIG1pY3Jvc29mdExpa2VseTogc3J2QXV0b2Rpc2NvdmVyLnNvbWUoKHIpID0+IHIubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwib3V0bG9vay5jb21cIikpIHx8IHNydkF1dG9kaXNjb3Zlci5sZW5ndGggPiAwLFxuICAgIHNldHRpbmdzOlxuICAgICAgaW1hcEhvc3QgJiYgc210cEhvc3RcbiAgICAgICAgPyB7XG4gICAgICAgICAgICBpbWFwSG9zdCxcbiAgICAgICAgICAgIGltYXBQb3J0OiBzcnZJbWFwWzBdPy5wb3J0ID8/IDk5MyxcbiAgICAgICAgICAgIGltYXBTZWN1cml0eTogXCJTU0wvVExTXCIsXG4gICAgICAgICAgICBzbXRwSG9zdCxcbiAgICAgICAgICAgIHNtdHBQb3J0OiBzcnZTdWJtaXNzaW9uWzBdPy5wb3J0ID8/IDU4NyxcbiAgICAgICAgICAgIHNtdHBTZWN1cml0eTogc3J2U3VibWlzc2lvblswXT8ucG9ydCA9PT0gNDY1ID8gXCJTU0wvVExTXCIgOiBcIlNUQVJUVExTXCIsXG4gICAgICAgICAgfVxuICAgICAgICA6IG51bGwsXG4gIH07XG59XG5cbmV4cG9ydCBkZWZhdWx0IGFzeW5jIChyZXF1ZXN0OiBSZXF1ZXN0KSA9PiB7XG4gIGNvbnN0IHVybCA9IG5ldyBVUkwocmVxdWVzdC51cmwpO1xuICBjb25zdCBpbnB1dCA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwiZW1haWxcIikgPz8gdXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJkb21haW5cIikgPz8gXCJcIjtcbiAgY29uc3QgZG9tYWluID0gbm9ybWFsaXNlRG9tYWluKGlucHV0KTtcblxuICBjb25zdCBoZWFkZXJzID0geyBcImNvbnRlbnQtdHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiwgXCJjYWNoZS1jb250cm9sXCI6IFwibm8tc3RvcmVcIiB9O1xuXG4gIGlmICghZG9tYWluKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShKU09OLnN0cmluZ2lmeSh7IGVycm9yOiBcIlByb3ZpZGUgP2VtYWlsPSBvciA/ZG9tYWluPVwiIH0pLCB7IHN0YXR1czogNDAwLCBoZWFkZXJzIH0pO1xuICB9XG5cbiAgY29uc3QgcmVjb3JkcyA9IGF3YWl0IHdpdGhUaW1lb3V0KHJlc29sdmVNeChkb21haW4pLCBbXSk7XG4gIGNvbnN0IG14ID0gcmVjb3Jkcy5zb3J0KChhLCBiKSA9PiBhLnByaW9yaXR5IC0gYi5wcmlvcml0eSkubWFwKChyKSA9PiByLmV4Y2hhbmdlLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFwuJC8sIFwiXCIpKTtcblxuICBjb25zdCBrbm93biA9IG1hdGNoUHJvdmlkZXIobXgsIGRvbWFpbik7XG5cbiAgaWYgKGtub3duKSB7XG4gICAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgZG9tYWluLFxuICAgICAgICBwcm92aWRlcjoga25vd24ua2V5LFxuICAgICAgICBwcm92aWRlck5hbWU6IGtub3duLm5hbWUsXG4gICAgICAgIG1ldGhvZDoga25vd24ubWV0aG9kLFxuICAgICAgICBteCxcbiAgICAgICAgY2hlY2tzOiB7IGluY29taW5nOiB0cnVlLCBvdXRnb2luZzogdHJ1ZSwgc2VjdXJpdHk6IHRydWUgfSxcbiAgICAgICAgc2V0dGluZ3M6IGtub3duLnNldHRpbmdzLFxuICAgICAgICBhdXRvZGlzY292ZXI6IG51bGwsXG4gICAgICAgIG5vdGU6IGtub3duLm5vdGUsXG4gICAgICAgIHNvdXJjZTogXCJteFwiLFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnMgfSxcbiAgICApO1xuICB9XG5cbiAgY29uc3QgZGlzY292ZXJ5ID0gYXdhaXQgYXV0b2Rpc2NvdmVyKGRvbWFpbik7XG5cbiAgaWYgKGRpc2NvdmVyeS5mb3VuZCAmJiBkaXNjb3ZlcnkubWljcm9zb2Z0TGlrZWx5ICYmICFteC5sZW5ndGgpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBkb21haW4sXG4gICAgICAgIHByb3ZpZGVyOiBcIm1pY3Jvc29mdFwiLFxuICAgICAgICBwcm92aWRlck5hbWU6IFwiTWljcm9zb2Z0IDM2NVwiLFxuICAgICAgICBtZXRob2Q6IFwib2F1dGhcIixcbiAgICAgICAgbXgsXG4gICAgICAgIGNoZWNrczogeyBpbmNvbWluZzogdHJ1ZSwgb3V0Z29pbmc6IHRydWUsIHNlY3VyaXR5OiB0cnVlIH0sXG4gICAgICAgIHNldHRpbmdzOiBudWxsLFxuICAgICAgICBhdXRvZGlzY292ZXI6IHsgc3J2OiBkaXNjb3Zlcnkuc3J2LCBodHRwczogZGlzY292ZXJ5Lmh0dHBzIH0sXG4gICAgICAgIG5vdGU6IFwiRm91bmQgdGhyb3VnaCBBdXRvZGlzY292ZXIgcmF0aGVyIHRoYW4gTVguXCIsXG4gICAgICAgIHNvdXJjZTogXCJhdXRvZGlzY292ZXJcIixcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzIH0sXG4gICAgKTtcbiAgfVxuXG4gIGlmIChkaXNjb3Zlcnkuc2V0dGluZ3MpIHtcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBkb21haW4sXG4gICAgICAgIHByb3ZpZGVyOiBcImF1dG9kaXNjb3ZlcmVkXCIsXG4gICAgICAgIHByb3ZpZGVyTmFtZTogbXgubGVuZ3RoID8gYE1haWwgaG9zdCBhdCAke214WzBdfWAgOiBgTWFpbCBob3N0IGZvciAke2RvbWFpbn1gLFxuICAgICAgICBtZXRob2Q6IFwiY3JlZGVudGlhbHNcIixcbiAgICAgICAgbXgsXG4gICAgICAgIGNoZWNrczoge1xuICAgICAgICAgIGluY29taW5nOiBCb29sZWFuKGRpc2NvdmVyeS5zZXR0aW5ncy5pbWFwSG9zdCksXG4gICAgICAgICAgb3V0Z29pbmc6IEJvb2xlYW4oZGlzY292ZXJ5LnNldHRpbmdzLnNtdHBIb3N0KSxcbiAgICAgICAgICBzZWN1cml0eTogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgc2V0dGluZ3M6IGRpc2NvdmVyeS5zZXR0aW5ncyxcbiAgICAgICAgYXV0b2Rpc2NvdmVyOiB7IHNydjogZGlzY292ZXJ5LnNydiwgaHR0cHM6IGRpc2NvdmVyeS5odHRwcyB9LFxuICAgICAgICBub3RlOiBcIlNldHRpbmdzIGZvdW5kIGJ5IGF1dG9kaXNjb3ZlcnkuIENvbmZpcm0gdGhlbSBiZWZvcmUgY29ubmVjdGluZy5cIixcbiAgICAgICAgc291cmNlOiBcImF1dG9kaXNjb3ZlclwiLFxuICAgICAgfSksXG4gICAgICB7IGhlYWRlcnMgfSxcbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIG5ldyBSZXNwb25zZShcbiAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICBkb21haW4sXG4gICAgICBwcm92aWRlcjogXCJ1bmtub3duXCIsXG4gICAgICBwcm92aWRlck5hbWU6IFwiVW5rbm93biBwcm92aWRlclwiLFxuICAgICAgbWV0aG9kOiBcIm1hbnVhbFwiLFxuICAgICAgbXgsXG4gICAgICBjaGVja3M6IHsgaW5jb21pbmc6IGZhbHNlLCBvdXRnb2luZzogZmFsc2UsIHNlY3VyaXR5OiBmYWxzZSB9LFxuICAgICAgc2V0dGluZ3M6IG51bGwsXG4gICAgICBhdXRvZGlzY292ZXI6IHsgc3J2OiBkaXNjb3Zlcnkuc3J2LCBodHRwczogZGlzY292ZXJ5Lmh0dHBzIH0sXG4gICAgICBub3RlOiBteC5sZW5ndGhcbiAgICAgICAgPyBgWW91ciBkb21haW4gcmVjZWl2ZXMgbWFpbCBhdCAke214WzBdfSwgYnV0IHdlIGRvIG5vdCByZWNvZ25pc2UgaXQuYFxuICAgICAgICA6IFwiTm8gbWFpbCBzZXJ2ZXJzIGZvdW5kIGZvciB0aGlzIGRvbWFpbi5cIixcbiAgICAgIHNvdXJjZTogXCJub25lXCIsXG4gICAgfSksXG4gICAgeyBoZWFkZXJzIH0sXG4gICk7XG59O1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7OztBQWVBLFNBQVMsV0FBVyxZQUFZLGdCQUFnQjtBQUV6QyxJQUFNLFNBQVM7QUFBQSxFQUNwQixNQUFNO0FBQ1I7QUF1QkEsSUFBTSxNQUFNLENBQUMsVUFBa0IsY0FBc0M7QUFBQSxFQUNuRTtBQUFBLEVBQ0EsVUFBVTtBQUFBLEVBQ1YsY0FBYztBQUFBLEVBQ2Q7QUFBQSxFQUNBLFVBQVU7QUFBQSxFQUNWLGNBQWM7QUFDaEI7QUFFQSxJQUFNLFlBQXdCO0FBQUEsRUFDNUI7QUFBQSxJQUNFLEtBQUs7QUFBQSxJQUNMLE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxJQUNSLFdBQVcsQ0FBQyxzQkFBc0Isa0JBQWtCLGNBQWMsV0FBVztBQUFBLElBQzdFLE1BQU07QUFBQSxFQUNSO0FBQUEsRUFDQTtBQUFBLElBQ0UsS0FBSztBQUFBLElBQ0wsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLElBQ1IsV0FBVyxDQUFDLCtCQUErQiwwQkFBMEIsZUFBZSxlQUFlO0FBQUEsSUFDbkcsTUFBTTtBQUFBLEVBQ1I7QUFBQSxFQUNBO0FBQUEsSUFDRSxLQUFLO0FBQUEsSUFDTCxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsSUFDUixXQUFXLENBQUMsYUFBYSxhQUFhO0FBQUEsSUFDdEMsVUFBVSxNQUFNLElBQUksb0JBQW9CLGtCQUFrQjtBQUFBLElBQzFELE1BQU07QUFBQSxFQUNSO0FBQUEsRUFDQTtBQUFBLElBQ0UsS0FBSztBQUFBLElBQ0wsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLElBQ1IsV0FBVyxDQUFDLFlBQVksV0FBVyxVQUFVO0FBQUEsSUFDN0MsVUFBVSxDQUFDLFdBQVksT0FBTyxTQUFTLEtBQUssSUFBSSxJQUFJLGdCQUFnQixjQUFjLElBQUksSUFBSSxpQkFBaUIsZUFBZTtBQUFBLElBQzFILE1BQU07QUFBQSxFQUNSO0FBQUEsRUFDQTtBQUFBLElBQ0UsS0FBSztBQUFBLElBQ0wsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLElBQ1IsV0FBVyxDQUFDLHVCQUF1QixVQUFVO0FBQUEsSUFDN0MsVUFBVSxNQUFNLElBQUkscUJBQXFCLG1CQUFtQjtBQUFBLElBQzVELE1BQU07QUFBQSxFQUNSO0FBQUEsRUFDQTtBQUFBLElBQ0UsS0FBSztBQUFBLElBQ0wsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLElBQ1IsV0FBVyxDQUFDLGlCQUFpQixhQUFhLGdCQUFnQjtBQUFBLElBQzFELFVBQVUsT0FBTztBQUFBLE1BQ2YsVUFBVTtBQUFBLE1BQ1YsVUFBVTtBQUFBLE1BQ1YsY0FBYztBQUFBLE1BQ2QsVUFBVTtBQUFBLE1BQ1YsVUFBVTtBQUFBLE1BQ1YsY0FBYztBQUFBLElBQ2hCO0FBQUEsSUFDQSxNQUFNO0FBQUEsRUFDUjtBQUFBLEVBQ0E7QUFBQSxJQUNFLEtBQUs7QUFBQSxJQUNMLE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxJQUNSLFdBQVcsQ0FBQyxTQUFTLFNBQVMsZ0JBQWdCLFNBQVM7QUFBQSxJQUN2RCxVQUFVLE1BQU0sSUFBSSxrQkFBa0IsZ0JBQWdCO0FBQUEsRUFDeEQ7QUFBQSxFQUNBO0FBQUEsSUFDRSxLQUFLO0FBQUEsSUFDTCxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsSUFDUixXQUFXLENBQUMsV0FBVyxTQUFTO0FBQUEsSUFDaEMsVUFBVSxNQUFNLElBQUksZ0JBQWdCLGNBQWM7QUFBQSxFQUNwRDtBQUFBLEVBQ0E7QUFBQSxJQUNFLEtBQUs7QUFBQSxJQUNMLE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxJQUNSLFdBQVcsQ0FBQyxvQkFBb0IsU0FBUztBQUFBLElBQ3pDLFVBQVUsTUFBTSxJQUFJLHlCQUF5QiwwQkFBMEI7QUFBQSxFQUN6RTtBQUNGO0FBRUEsSUFBTSxhQUFhO0FBRW5CLGVBQWUsWUFBZSxNQUFrQixVQUF5QjtBQUN2RSxNQUFJO0FBQ0osUUFBTSxVQUFVLElBQUksUUFBVyxDQUFDLFlBQVk7QUFDMUMsWUFBUSxXQUFXLE1BQU0sUUFBUSxRQUFRLEdBQUcsVUFBVTtBQUFBLEVBQ3hELENBQUM7QUFDRCxNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxDQUFDLEtBQUssTUFBTSxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUM7QUFBQSxFQUNqRSxVQUFFO0FBQ0EsUUFBSSxNQUFPLGNBQWEsS0FBSztBQUFBLEVBQy9CO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixPQUE4QjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxLQUFLLEVBQUUsWUFBWTtBQUNyQyxRQUFNLFNBQVMsSUFBSSxTQUFTLEdBQUcsSUFBSSxJQUFJLE1BQU0sSUFBSSxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUk7QUFDekUsUUFBTSxVQUFVLE9BQU8sUUFBUSxnQkFBZ0IsRUFBRSxFQUFFLFFBQVEsU0FBUyxFQUFFLEVBQUUsUUFBUSxPQUFPLEVBQUU7QUFDekYsTUFBSSxDQUFDLG9FQUFvRSxLQUFLLE9BQU8sRUFBRyxRQUFPO0FBQy9GLFNBQU87QUFDVDtBQUVBLFNBQVMsY0FBYyxJQUFjLFFBQWdCO0FBQ25ELFFBQU0sV0FBVyxHQUFHLEtBQUssR0FBRztBQUM1QixhQUFXLFlBQVksV0FBVztBQUNoQyxRQUFJLFNBQVMsVUFBVSxLQUFLLENBQUMsTUFBTSxTQUFTLFNBQVMsQ0FBQyxDQUFDLEdBQUc7QUFDeEQsYUFBTztBQUFBLFFBQ0wsS0FBSyxTQUFTO0FBQUEsUUFDZCxNQUFNLFNBQVM7QUFBQSxRQUNmLFFBQVEsU0FBUztBQUFBLFFBQ2pCLFVBQVUsU0FBUyxXQUFXLFNBQVMsU0FBUyxNQUFNLElBQUk7QUFBQSxRQUMxRCxNQUFNLFNBQVMsUUFBUTtBQUFBLE1BQ3pCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFPQSxlQUFlLGFBQWEsUUFBZ0I7QUFDMUMsUUFBTSxrQkFBa0IsTUFBTSxZQUFZLFdBQVcsc0JBQXNCLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQztBQUN4RixRQUFNLFVBQVUsTUFBTSxZQUFZLFdBQVcsZUFBZSxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7QUFDekUsUUFBTSxnQkFBZ0IsTUFBTTtBQUFBLElBQzFCLFdBQVcsb0JBQW9CLE1BQU0sRUFBRSxFQUFFLE1BQU0sTUFBTSxXQUFXLHFCQUFxQixNQUFNLEVBQUUsQ0FBQztBQUFBLElBQzlGLENBQUM7QUFBQSxFQUNIO0FBRUEsTUFBSSxRQUFRO0FBQ1osTUFBSTtBQUNGLFVBQU0sYUFBYSxJQUFJLGdCQUFnQjtBQUN2QyxVQUFNLFFBQVEsV0FBVyxNQUFNLFdBQVcsTUFBTSxHQUFHLFVBQVU7QUFDN0QsVUFBTSxXQUFXLE1BQU0sTUFBTSx3QkFBd0IsTUFBTSxrQ0FBa0M7QUFBQSxNQUMzRixRQUFRO0FBQUEsTUFDUixVQUFVO0FBQUEsTUFDVixRQUFRLFdBQVc7QUFBQSxJQUNyQixDQUFDO0FBQ0QsaUJBQWEsS0FBSztBQUVsQixZQUFRLFNBQVMsV0FBVztBQUFBLEVBQzlCLFFBQVE7QUFDTixZQUFRO0FBQUEsRUFDVjtBQUVBLFFBQU0sVUFBVSxNQUFNLFFBQVE7QUFBQSxJQUM1QixDQUFDLFFBQVEsUUFBUSxNQUFNLEVBQUUsSUFBSSxPQUFPLFdBQVc7QUFDN0MsWUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJLE1BQU07QUFDaEMsWUFBTSxZQUFZLE1BQU0sWUFBWSxTQUFTLElBQUksR0FBRyxDQUFDLENBQUM7QUFDdEQsYUFBTyxVQUFVLFNBQVMsT0FBTztBQUFBLElBQ25DLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTSxXQUFXLFFBQVEsQ0FBQyxHQUFHLFFBQVEsUUFBUSxDQUFDLEtBQUssUUFBUSxDQUFDO0FBQzVELFFBQU0sV0FBVyxjQUFjLENBQUMsR0FBRyxRQUFRLFFBQVEsQ0FBQyxLQUFLLFFBQVEsQ0FBQztBQUVsRSxRQUFNLFFBQVEsUUFBUSxnQkFBZ0IsVUFBVSxTQUFTLFlBQVksUUFBUTtBQUU3RSxTQUFPO0FBQUEsSUFDTCxPQUFPO0FBQUEsSUFDUCxLQUFLLGdCQUFnQixTQUFTO0FBQUEsSUFDOUI7QUFBQSxJQUNBO0FBQUEsSUFDQSxpQkFBaUIsZ0JBQWdCLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxZQUFZLEVBQUUsU0FBUyxhQUFhLENBQUMsS0FBSyxnQkFBZ0IsU0FBUztBQUFBLElBQ3ZILFVBQ0UsWUFBWSxXQUNSO0FBQUEsTUFDRTtBQUFBLE1BQ0EsVUFBVSxRQUFRLENBQUMsR0FBRyxRQUFRO0FBQUEsTUFDOUIsY0FBYztBQUFBLE1BQ2Q7QUFBQSxNQUNBLFVBQVUsY0FBYyxDQUFDLEdBQUcsUUFBUTtBQUFBLE1BQ3BDLGNBQWMsY0FBYyxDQUFDLEdBQUcsU0FBUyxNQUFNLFlBQVk7QUFBQSxJQUM3RCxJQUNBO0FBQUEsRUFDUjtBQUNGO0FBRUEsSUFBTyx1QkFBUSxPQUFPLFlBQXFCO0FBQ3pDLFFBQU0sTUFBTSxJQUFJLElBQUksUUFBUSxHQUFHO0FBQy9CLFFBQU0sUUFBUSxJQUFJLGFBQWEsSUFBSSxPQUFPLEtBQUssSUFBSSxhQUFhLElBQUksUUFBUSxLQUFLO0FBQ2pGLFFBQU0sU0FBUyxnQkFBZ0IsS0FBSztBQUVwQyxRQUFNLFVBQVUsRUFBRSxnQkFBZ0Isb0JBQW9CLGlCQUFpQixXQUFXO0FBRWxGLE1BQUksQ0FBQyxRQUFRO0FBQ1gsV0FBTyxJQUFJLFNBQVMsS0FBSyxVQUFVLEVBQUUsT0FBTyw4QkFBOEIsQ0FBQyxHQUFHLEVBQUUsUUFBUSxLQUFLLFFBQVEsQ0FBQztBQUFBLEVBQ3hHO0FBRUEsUUFBTSxVQUFVLE1BQU0sWUFBWSxVQUFVLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDdkQsUUFBTSxLQUFLLFFBQVEsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLFlBQVksRUFBRSxRQUFRLE9BQU8sRUFBRSxDQUFDO0FBRWpILFFBQU0sUUFBUSxjQUFjLElBQUksTUFBTTtBQUV0QyxNQUFJLE9BQU87QUFDVCxXQUFPLElBQUk7QUFBQSxNQUNULEtBQUssVUFBVTtBQUFBLFFBQ2I7QUFBQSxRQUNBLFVBQVUsTUFBTTtBQUFBLFFBQ2hCLGNBQWMsTUFBTTtBQUFBLFFBQ3BCLFFBQVEsTUFBTTtBQUFBLFFBQ2Q7QUFBQSxRQUNBLFFBQVEsRUFBRSxVQUFVLE1BQU0sVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLFFBQ3pELFVBQVUsTUFBTTtBQUFBLFFBQ2hCLGNBQWM7QUFBQSxRQUNkLE1BQU0sTUFBTTtBQUFBLFFBQ1osUUFBUTtBQUFBLE1BQ1YsQ0FBQztBQUFBLE1BQ0QsRUFBRSxRQUFRO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFlBQVksTUFBTSxhQUFhLE1BQU07QUFFM0MsTUFBSSxVQUFVLFNBQVMsVUFBVSxtQkFBbUIsQ0FBQyxHQUFHLFFBQVE7QUFDOUQsV0FBTyxJQUFJO0FBQUEsTUFDVCxLQUFLLFVBQVU7QUFBQSxRQUNiO0FBQUEsUUFDQSxVQUFVO0FBQUEsUUFDVixjQUFjO0FBQUEsUUFDZCxRQUFRO0FBQUEsUUFDUjtBQUFBLFFBQ0EsUUFBUSxFQUFFLFVBQVUsTUFBTSxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsUUFDekQsVUFBVTtBQUFBLFFBQ1YsY0FBYyxFQUFFLEtBQUssVUFBVSxLQUFLLE9BQU8sVUFBVSxNQUFNO0FBQUEsUUFDM0QsTUFBTTtBQUFBLFFBQ04sUUFBUTtBQUFBLE1BQ1YsQ0FBQztBQUFBLE1BQ0QsRUFBRSxRQUFRO0FBQUEsSUFDWjtBQUFBLEVBQ0Y7QUFFQSxNQUFJLFVBQVUsVUFBVTtBQUN0QixXQUFPLElBQUk7QUFBQSxNQUNULEtBQUssVUFBVTtBQUFBLFFBQ2I7QUFBQSxRQUNBLFVBQVU7QUFBQSxRQUNWLGNBQWMsR0FBRyxTQUFTLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxLQUFLLGlCQUFpQixNQUFNO0FBQUEsUUFDM0UsUUFBUTtBQUFBLFFBQ1I7QUFBQSxRQUNBLFFBQVE7QUFBQSxVQUNOLFVBQVUsUUFBUSxVQUFVLFNBQVMsUUFBUTtBQUFBLFVBQzdDLFVBQVUsUUFBUSxVQUFVLFNBQVMsUUFBUTtBQUFBLFVBQzdDLFVBQVU7QUFBQSxRQUNaO0FBQUEsUUFDQSxVQUFVLFVBQVU7QUFBQSxRQUNwQixjQUFjLEVBQUUsS0FBSyxVQUFVLEtBQUssT0FBTyxVQUFVLE1BQU07QUFBQSxRQUMzRCxNQUFNO0FBQUEsUUFDTixRQUFRO0FBQUEsTUFDVixDQUFDO0FBQUEsTUFDRCxFQUFFLFFBQVE7QUFBQSxJQUNaO0FBQUEsRUFDRjtBQUVBLFNBQU8sSUFBSTtBQUFBLElBQ1QsS0FBSyxVQUFVO0FBQUEsTUFDYjtBQUFBLE1BQ0EsVUFBVTtBQUFBLE1BQ1YsY0FBYztBQUFBLE1BQ2QsUUFBUTtBQUFBLE1BQ1I7QUFBQSxNQUNBLFFBQVEsRUFBRSxVQUFVLE9BQU8sVUFBVSxPQUFPLFVBQVUsTUFBTTtBQUFBLE1BQzVELFVBQVU7QUFBQSxNQUNWLGNBQWMsRUFBRSxLQUFLLFVBQVUsS0FBSyxPQUFPLFVBQVUsTUFBTTtBQUFBLE1BQzNELE1BQU0sR0FBRyxTQUNMLGdDQUFnQyxHQUFHLENBQUMsQ0FBQyxrQ0FDckM7QUFBQSxNQUNKLFFBQVE7QUFBQSxJQUNWLENBQUM7QUFBQSxJQUNELEVBQUUsUUFBUTtBQUFBLEVBQ1o7QUFDRjsiLAogICJuYW1lcyI6IFtdCn0K
