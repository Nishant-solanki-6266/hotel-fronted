/**
 * Email provider detection.
 *
 * The manager types the mailbox they want guest email to arrive in; this runs the
 * lookup chain the onboarding wizard describes:
 *
 *   extract domain -> DNS MX lookup -> recognise provider
 *     known provider  -> return the right connection method (OAuth or credentials)
 *     unknown         -> autodiscovery (Autodiscover SRV + HTTPS, RFC 6186 SRV, host guesses)
 *     still unknown   -> tell the client to show manual IMAP/SMTP settings
 *
 * Nothing here is stored and no credential is ever accepted by this endpoint --
 * it only answers "how should this mailbox be connected?".
 */

import { resolveMx, resolveSrv, resolve4 } from "node:dns/promises";

export const config = {
  path: "/api/email-detect",
};

type Method = "oauth" | "credentials" | "manual";

type ServerSettings = {
  imapHost: string;
  imapPort: number;
  imapSecurity: string;
  smtpHost: string;
  smtpPort: number;
  smtpSecurity: string;
};

type Provider = {
  key: string;
  name: string;
  method: Method;
  /** substrings matched against the domain's MX hostnames, lowercased */
  mxMatches: string[];
  settings?: (domain: string) => ServerSettings;
  note?: string;
};

const ssl = (imapHost: string, smtpHost: string): ServerSettings => ({
  imapHost,
  imapPort: 993,
  imapSecurity: "SSL/TLS",
  smtpHost,
  smtpPort: 465,
  smtpSecurity: "SSL/TLS",
});

const PROVIDERS: Provider[] = [
  {
    key: "google",
    name: "Google Workspace",
    method: "oauth",
    mxMatches: ["aspmx.l.google.com", "googlemail.com", "google.com", "psmtp.com"],
    note: "Sign in with Google — no password is stored.",
  },
  {
    key: "microsoft",
    name: "Microsoft 365",
    method: "oauth",
    mxMatches: ["mail.protection.outlook.com", "protection.outlook.com", "outlook.com", "office365.com"],
    note: "Sign in with Microsoft — no password is stored.",
  },
  {
    key: "hostinger",
    name: "Hostinger Email",
    method: "credentials",
    mxMatches: ["hostinger", "titan.email"],
    settings: () => ssl("imap.titan.email", "smtp.titan.email"),
    note: "Hostinger mailboxes run on Titan. Use your mailbox password or an app password.",
  },
  {
    key: "zoho",
    name: "Zoho Mail",
    method: "credentials",
    mxMatches: ["zoho.com", "zoho.eu", "zohomail"],
    settings: (domain) => (domain.endsWith(".eu") ? ssl("imap.zoho.eu", "smtp.zoho.eu") : ssl("imap.zoho.com", "smtp.zoho.com")),
    note: "Zoho requires an application-specific password when two-factor is on.",
  },
  {
    key: "fastmail",
    name: "Fastmail",
    method: "credentials",
    mxMatches: ["messagingengine.com", "fastmail"],
    settings: () => ssl("imap.fastmail.com", "smtp.fastmail.com"),
    note: "Fastmail requires an app password for IMAP and SMTP.",
  },
  {
    key: "proton",
    name: "Proton Mail",
    method: "credentials",
    mxMatches: ["protonmail.ch", "proton.me", "protonmail.com"],
    settings: () => ({
      imapHost: "127.0.0.1",
      imapPort: 1143,
      imapSecurity: "STARTTLS (Proton Bridge)",
      smtpHost: "127.0.0.1",
      smtpPort: 1025,
      smtpSecurity: "STARTTLS (Proton Bridge)",
    }),
    note: "Proton needs Proton Bridge for IMAP access.",
  },
  {
    key: "ionos",
    name: "IONOS",
    method: "credentials",
    mxMatches: ["ionos", "1and1", "kundenserver", "perfora"],
    settings: () => ssl("imap.ionos.com", "smtp.ionos.com"),
  },
  {
    key: "ovh",
    name: "OVH",
    method: "credentials",
    mxMatches: ["ovh.net", "ovh.com"],
    settings: () => ssl("ssl0.ovh.net", "ssl0.ovh.net"),
  },
  {
    key: "godaddy",
    name: "GoDaddy / Secureserver",
    method: "credentials",
    mxMatches: ["secureserver.net", "godaddy"],
    settings: () => ssl("imap.secureserver.net", "smtpout.secureserver.net"),
  },
];

const TIMEOUT_MS = 2500;

async function withTimeout<T>(work: Promise<T>, fallback: T): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<T>((resolve) => {
    timer = setTimeout(() => resolve(fallback), TIMEOUT_MS);
  });
  try {
    return await Promise.race([work.catch(() => fallback), timeout]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function normaliseDomain(input: string): string | null {
  const raw = input.trim().toLowerCase();
  const domain = raw.includes("@") ? raw.slice(raw.lastIndexOf("@") + 1) : raw;
  const cleaned = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "").replace(/\.$/, "");
  if (!/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/.test(cleaned)) return null;
  return cleaned;
}

function matchProvider(mx: string[], domain: string) {
  const haystack = mx.join(" ");
  for (const provider of PROVIDERS) {
    if (provider.mxMatches.some((m) => haystack.includes(m))) {
      return {
        key: provider.key,
        name: provider.name,
        method: provider.method,
        settings: provider.settings ? provider.settings(domain) : null,
        note: provider.note ?? null,
      };
    }
  }
  return null;
}

/**
 * Microsoft documents that a client can derive Autodiscover endpoints from the mail
 * domain, and fall back to a DNS SRV record. We try both, plus the RFC 6186 service
 * records and the conventional host names, before giving up and asking for manual setup.
 */
async function autodiscover(domain: string) {
  const srvAutodiscover = await withTimeout(resolveSrv(`_autodiscover._tcp.${domain}`), []);
  const srvImap = await withTimeout(resolveSrv(`_imaps._tcp.${domain}`), []);
  const srvSubmission = await withTimeout(
    resolveSrv(`_submission._tcp.${domain}`).catch(() => resolveSrv(`_submissions._tcp.${domain}`)),
    [],
  );

  let https = false;
  try {
    const controller = new AbortController();
    const abort = setTimeout(() => controller.abort(), TIMEOUT_MS);
    const response = await fetch(`https://autodiscover.${domain}/autodiscover/autodiscover.xml`, {
      method: "GET",
      redirect: "follow",
      signal: controller.signal,
    });
    clearTimeout(abort);
    // Autodiscover answers POSTs; a 401/405/200 all prove the endpoint exists.
    https = response.status !== 404;
  } catch {
    https = false;
  }

  const guesses = await Promise.all(
    ["imap", "mail", "smtp"].map(async (prefix) => {
      const host = `${prefix}.${domain}`;
      const addresses = await withTimeout(resolve4(host), []);
      return addresses.length ? host : null;
    }),
  );

  const imapHost = srvImap[0]?.name ?? guesses[0] ?? guesses[1];
  const smtpHost = srvSubmission[0]?.name ?? guesses[2] ?? guesses[1];

  const found = Boolean(srvAutodiscover.length || https || imapHost || smtpHost);

  return {
    tried: true,
    srv: srvAutodiscover.length > 0,
    https,
    found,
    microsoftLikely: srvAutodiscover.some((r) => r.name.toLowerCase().includes("outlook.com")) || srvAutodiscover.length > 0,
    settings:
      imapHost && smtpHost
        ? {
            imapHost,
            imapPort: srvImap[0]?.port ?? 993,
            imapSecurity: "SSL/TLS",
            smtpHost,
            smtpPort: srvSubmission[0]?.port ?? 587,
            smtpSecurity: srvSubmission[0]?.port === 465 ? "SSL/TLS" : "STARTTLS",
          }
        : null,
  };
}

export default async (request: Request) => {
  const url = new URL(request.url);
  const input = url.searchParams.get("email") ?? url.searchParams.get("domain") ?? "";
  const domain = normaliseDomain(input);

  const headers = { "content-type": "application/json", "cache-control": "no-store" };

  if (!domain) {
    return new Response(JSON.stringify({ error: "Provide ?email= or ?domain=" }), { status: 400, headers });
  }

  const records = await withTimeout(resolveMx(domain), []);
  const mx = records.sort((a, b) => a.priority - b.priority).map((r) => r.exchange.toLowerCase().replace(/\.$/, ""));

  const known = matchProvider(mx, domain);

  if (known) {
    return new Response(
      JSON.stringify({
        domain,
        provider: known.key,
        providerName: known.name,
        method: known.method,
        mx,
        checks: { incoming: true, outgoing: true, security: true },
        settings: known.settings,
        autodiscover: null,
        note: known.note,
        source: "mx",
      }),
      { headers },
    );
  }

  const discovery = await autodiscover(domain);

  if (discovery.found && discovery.microsoftLikely && !mx.length) {
    return new Response(
      JSON.stringify({
        domain,
        provider: "microsoft",
        providerName: "Microsoft 365",
        method: "oauth",
        mx,
        checks: { incoming: true, outgoing: true, security: true },
        settings: null,
        autodiscover: { srv: discovery.srv, https: discovery.https },
        note: "Found through Autodiscover rather than MX.",
        source: "autodiscover",
      }),
      { headers },
    );
  }

  if (discovery.settings) {
    return new Response(
      JSON.stringify({
        domain,
        provider: "autodiscovered",
        providerName: mx.length ? `Mail host at ${mx[0]}` : `Mail host for ${domain}`,
        method: "credentials",
        mx,
        checks: {
          incoming: Boolean(discovery.settings.imapHost),
          outgoing: Boolean(discovery.settings.smtpHost),
          security: true,
        },
        settings: discovery.settings,
        autodiscover: { srv: discovery.srv, https: discovery.https },
        note: "Settings found by autodiscovery. Confirm them before connecting.",
        source: "autodiscover",
      }),
      { headers },
    );
  }

  return new Response(
    JSON.stringify({
      domain,
      provider: "unknown",
      providerName: "Unknown provider",
      method: "manual",
      mx,
      checks: { incoming: false, outgoing: false, security: false },
      settings: null,
      autodiscover: { srv: discovery.srv, https: discovery.https },
      note: mx.length
        ? `Your domain receives mail at ${mx[0]}, but we do not recognise it.`
        : "No mail servers found for this domain.",
      source: "none",
    }),
    { headers },
  );
};
